
#include "mcc_generated_files/mcc.h"


#include "FreeRTOS.h"
#include "task.h"
static void task1(void *pvParameters) {
    for(;;){
        if(IO_RB7_GetValue()){
            IO_RA0_SetLow();
        }else{
            IO_RA0_SetHigh();
        }
    }
}

/*
 * Cria a segunda task e utiliza como entrada RB13 e sa�da RC9
*/
static void task2(void *pvParameters) {

    for(;;){
        if(IO_RB13_GetValue()){
            IO_RC9_SetLow();
        }else{
            IO_RC9_SetHigh();
        }
    }
}


void main(void) {
    SYSTEM_Initialize();

    xTaskCreate(task1, /* The function that implements the task. */
          "Rx", /* The text name assigned to the task - for debug only. */
          configMINIMAL_STACK_SIZE, /* The size of the stack to allocate to the task. */
            NULL, /* The parameter passed to the task - just to check functionality. */
          tskIDLE_PRIORITY+1, /* The priority assigned to the task. */
          NULL);
/*
 * Adiciona a task e no kernel.
*/
xTaskCreate(task2, /* The function that implements the task. */
		"LigaLED2", /* The text name assigned to the task - for debug only as it is not used by the kernel. */
		configMINIMAL_STACK_SIZE, /* The size of the stack to allocate to the task. */
		NULL, /* The parameter passed to the task - just to check the functionality. */
		tskIDLE_PRIORITY+1, /* The priority assigned to the task. */
		NULL);

    /* Start the tasks and timer running. */
    vTaskStartScheduler();
}

/**
 End of File
*/