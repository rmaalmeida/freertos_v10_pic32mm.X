
#include "mcc_generated_files/mcc.h"


#include "FreeRTOS.h"
#include "task.h"

static void task1(void *pvParameters) {
    for (;;) {
        if (IO_RB7_GetValue()) {
            IO_RA0_SetLow();
        } else {
            IO_RA0_SetHigh();
        }
    }
}

/*
 * Task com token para detec��o de borda
 * e acionamento mutuo das tasks, mesmo com prioridade diferente.
 * Lembrar que o vTaskDelay coloca a task em estado blocked.
 */
static void task2(void *pvParameters) {
    bool token = false;
    for (;;) {
        if (token == !IO_RB13_GetValue()) {
            vTaskDelay(20/portTICK_PERIOD_MS);
        }else{
            token = !IO_RB13_GetValue();
            IO_RC9_Toggle();
        }

    }
}


void main(void) {
    SYSTEM_Initialize();

    xTaskCreate(task1, /* The function that implements the task. */
            "Rx", /* The text name assigned to the task - for debug only. */
            configMINIMAL_STACK_SIZE, /* The size of the stack to allocate to the task. */
            NULL, /* The parameter passed to the task - just to check functionality. */
            tskIDLE_PRIORITY + 1, /* The priority assigned to the task. */
            NULL);
    /*
     * Adiciona a task 2 no kernel.
     */
    xTaskCreate(task2, /* The function that implements the task. */
            "LigaLED2", /* The text name assigned to the task - for debug only as it is not used by the kernel. */
            configMINIMAL_STACK_SIZE, /* The size of the stack to allocate to the task. */
            NULL, /* The parameter passed to the task - just to check the functionality. */
            tskIDLE_PRIORITY + 2, /* The priority assigned to the task. */
            NULL);

    /* Start the tasks and timer running. */
    vTaskStartScheduler();
}

/**
 End of File
 */