
#include "mcc_generated_files/mcc.h"


#include "FreeRTOS.h"
#include "task.h"

enum {
   LED_STATE_OFF, LED_STATE_ON
};

#include "queue.h"
typedef struct {
    unsigned int num; // 1, 2
    unsigned int status; // LED_STATE_OFF, LED_STATE_ON
} LedInfo;

QueueHandle_t ledQueue;

void taskLeds(void *pvParameters) {
    LedInfo led;
    for (;;) {
        xQueueReceive(ledQueue, &led, portMAX_DELAY);
        if (led.num == 1) {
            if (led.status == LED_STATE_ON) {
                IO_RA0_SetHigh();
            } else {
                IO_RA0_SetLow();
            }
        }
         if (led.num == 2) {
            if (led.status == LED_STATE_ON) {
                IO_RC9_SetHigh();
            } else {
                IO_RC9_SetLow();
            }
        }
    }
}

void taskButtons(void *pvParameters) {
    LedInfo led;
    int num = 1;
    for (;;) {
        led.num = 1;
        if (!IO_RB7_GetValue()) {
            led.status = LED_STATE_ON;
        } else {
            led.status = LED_STATE_OFF;
        }
        xQueueSend(ledQueue, &led, portMAX_DELAY);
        
        led.num = 2;
        if (!IO_RB13_GetValue()) {
            led.status = LED_STATE_ON;
        } else {
            led.status = LED_STATE_OFF;
        }
        xQueueSend(ledQueue, &led, portMAX_DELAY);
    }
}


void main(void) {
    SYSTEM_Initialize();

    xTaskCreate(taskLeds, /* The function that implements the task. */
            "Led", /* The text name assigned to the task - for debug only. */
            configMINIMAL_STACK_SIZE, /* The size of the stack to allocate to the task. */
            NULL, /* The parameter passed to the task - just to check functionality. */
            tskIDLE_PRIORITY + 1, /* The priority assigned to the task. */
            NULL);
    /*
     * Adiciona a task 2 no kernel.
     */
    xTaskCreate(taskButtons, /* The function that implements the task. */
            "Button", /* The text name assigned to the task - for debug only as it is not used by the kernel. */
            configMINIMAL_STACK_SIZE, /* The size of the stack to allocate to the task. */
            NULL, /* The parameter passed to the task - just to check the functionality. */
            tskIDLE_PRIORITY + 2, /* The priority assigned to the task. */
            NULL);

    ledQueue = xQueueCreate(3, sizeof(LedInfo));
  
    /* Start the tasks and timer running. */
    vTaskStartScheduler();
}

/**
 End of File
 */