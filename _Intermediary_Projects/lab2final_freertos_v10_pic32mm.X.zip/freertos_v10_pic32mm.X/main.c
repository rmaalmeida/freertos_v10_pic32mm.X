
#include "mcc_generated_files/mcc.h"


#include "FreeRTOS.h"
#include "task.h"

enum {
   LED_STATE_OFF, LED_STATE_ON
};

#include "queue.h"
typedef struct {
    unsigned int num; // 1, 2
    unsigned int status; // LED_STATE_OFF, LED_STATE_ON
} LedInfo;

QueueHandle_t ledQueue;

void taskLeds(void *pvParameters) {
    LedInfo led;
    for (;;) {
        xQueueReceive(ledQueue, &led, portMAX_DELAY);
        if (led.num == 1) {
            if (led.status == LED_STATE_ON) {
                IO_RA0_SetHigh();
            } else {
                IO_RA0_SetLow();
            }
        }
         if (led.num == 2) {
            if (led.status == LED_STATE_ON) {
                IO_RC9_SetHigh();
            } else {
                IO_RC9_SetLow();
            }
        }
    }
}

void taskButtons(void *pvParameters) {
    LedInfo led;
    int num = 1;
    for (;;) {
        led.num = 1;
        if (!IO_RB7_GetValue()) {
            led.status = LED_STATE_ON;
        } else {
            led.status = LED_STATE_OFF;
        }
        xQueueSend(ledQueue, &led, portMAX_DELAY);
        
        led.num = 2;
        if (!IO_RB13_GetValue()) {
            led.status = LED_STATE_ON;
        } else {
            led.status = LED_STATE_OFF;
        }
        xQueueSend(ledQueue, &led, portMAX_DELAY);
    }
}


QueueHandle_t pwmQueue;

static  void lerADC(void *pvParameters) {
    int i;
    unsigned int conversion = 0;
    ADC1_ChannelSelect(ADC1_CHANNEL_AN11);
    for (;;) {
        ADC1_Start();
        for (i = 0; i < 1000; i++);
        ADC1_Stop();
        while (!ADC1_IsConversionComplete());
        if (conversion != ADC1_ConversionResultGet()) {
            conversion = ADC1_ConversionResultGet();
            xQueueSend(pwmQueue, &conversion, portMAX_DELAY);
        } else {
            vTaskDelay(10 / portTICK_PERIOD_MS);
        }
    }
}

static void taskPwm(void *pvParameters) {
    float t;
    int readValor = 0;
    MCCP1_COMPARE_Start();
    for (;;) {        
        xQueueReceive(pwmQueue, &readValor, portMAX_DELAY);
        MCCP1_COMPARE_CenterAlignedPWMConfig(0, readValor);
    }
}


void main(void) {
    SYSTEM_Initialize();

    xTaskCreate(lerADC, /* The function that implements the task. */
            "ADC", /* The text name assigned to the task - for debug only. */
            configMINIMAL_STACK_SIZE, /* The size of the stack to allocate to the task. */
            NULL, /* The parameter passed to the task - just to check functionality. */
            tskIDLE_PRIORITY + 1, /* The priority assigned to the task. */
            NULL);
    /*
     * Adiciona a task 2 no kernel.
     */
    xTaskCreate(taskPwm, /* The function that implements the task. */
            "PWM", /* The text name assigned to the task - for debug only as it is not used by the kernel. */
            configMINIMAL_STACK_SIZE, /* The size of the stack to allocate to the task. */
            NULL, /* The parameter passed to the task - just to check the functionality. */
            tskIDLE_PRIORITY + 2, /* The priority assigned to the task. */
            NULL);

    pwmQueue = xQueueCreate(3, sizeof(int));
  
    /* Start the tasks and timer running. */
    vTaskStartScheduler();
}

/**
 End of File
 */